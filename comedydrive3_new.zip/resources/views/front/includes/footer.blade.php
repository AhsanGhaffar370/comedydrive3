
    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
            </div>
            
        </div>
    </footer>

    <div class="copyright text-center">
        <div class="container">
            <p><script>new Date().getFullYear()>document.write(new Date().getFullYear());</script> © COMEDY SAFE DRIVER</p>
        </div>
    </div>
    <!-- footer -->


    @include('front/includes/script')