@extends('front/layout/layout')

@section('page_title','| Thank you')

@section('content')
   <section class="bar-sec">
      <div class="container">
         <div class="bar-land">
            <div class="row">
               <div class="col-md-12 text-center">
                  <div class="bar-hd">
                     <h3>Thank You</h3>
                     <div class="insta-btn wow fadeInUp" data-wow-delay="0.9s">
                        <a href="#">Continue</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
@endsection