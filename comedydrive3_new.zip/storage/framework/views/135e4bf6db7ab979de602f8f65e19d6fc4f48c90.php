
    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="widget">
                        
                    </div>
                </div>
            </div>
            
        </div>
    </footer>

    <div class="copyright text-center">
        <div class="container">
            <p><script>new Date().getFullYear()>document.write(new Date().getFullYear());</script> © COMEDY SAFE DRIVER</p>
        </div>
    </div>
    <!-- footer -->


    <?php echo $__env->make('front/includes/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/front/includes/footer.blade.php ENDPATH**/ ?>