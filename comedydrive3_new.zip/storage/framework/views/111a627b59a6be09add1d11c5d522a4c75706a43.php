
<?php $__env->startSection('page_title','| Get Enrolled'); ?>
<?php $__env->startSection('content'); ?>
<section class="entrolled-sec">
   <div class="container">
      <?php if($errors->any()): ?>
      <div class = 'alert alert-danger' role="alert">
         <h5 class="alert-heading">Something went wrong!</h5>
         <hr>
         <div class="alert-body">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
      </div>
      <?php endif; ?>
      <div class="contact-text">
         <div class="question-hd">
            <h1>Driving Record</h1>
         </div>
      </div>
      <form method="POST" action="<?php echo e(route('store_get_enrolled_step2_1')); ?>">
         <?php echo csrf_field(); ?>
         <div class="row">
            <div class="col-md-12">
               <div class="field">
               <p>Since you selected to get a certified copy of your driving record. <br> Please enter the info below so it can be processed.</p>
               </div>
            </div>
            <div class="col-md-8 mt-4">
               <div class="field">
                  <input type="text" placeholder="Last 4 Digits of SSN*"  name="ssn_no" value="<?php echo e(old('ssn_no')); ?>" required>
               </div>
            </div>
            <div class="col-md-4">
               <div class="field">
                  <img src="<?php echo e(asset('assets/images/ssn.jpg')); ?>" alt="">
               </div>
            </div>
            <div class="col-md-8 mt-4">
               <div class="field">
                  <input type="text" placeholder="DPS Audit Number*"  name="dps_audit_no" value="<?php echo e(old('dps_audit_no')); ?>" required>
               </div>
            </div>
            <div class="col-md-4">
               <div class="field">
                  <img src="<?php echo e(asset('assets/images/dps_no.jpg')); ?>" alt="">
               </div>
            </div>
         </div>
         <div class="field">
            <button type="submit">Submit</button>
         </div>
      </form>
   </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/front/get_enrolled_step2_1.blade.php ENDPATH**/ ?>