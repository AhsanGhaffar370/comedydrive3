<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('page_title'); ?></title>
     
</head>

<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php echo $__env->make('admin/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- page content -->
            <div class="right_col page_height" role="main" style="min-height: 1000px;">
               <?php echo $__env->yieldContent('content'); ?>
			   <?php echo $__env->yieldSection(); ?>
            </div>
            <!-- /page content -->

            <?php echo $__env->make('admin/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\comedydrive3\resources\views/admin/layout/layout.blade.php ENDPATH**/ ?>