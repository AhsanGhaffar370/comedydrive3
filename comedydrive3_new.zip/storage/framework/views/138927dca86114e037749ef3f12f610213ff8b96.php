

<?php $__env->startSection('page_title','| Thank you'); ?>

<?php $__env->startSection('content'); ?>
   <section class="bar-sec">
      <div class="container">
         <div class="bar-land">
            <div class="row">
               <div class="col-md-12 text-center">
                  <div class="bar-hd">
                     <h3>Thank You</h3>
                     <div class="insta-btn wow fadeInUp" data-wow-delay="0.9s">
                        <a href="#">Continue</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/front/thank_you.blade.php ENDPATH**/ ?>