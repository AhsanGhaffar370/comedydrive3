

<?php $__env->startSection('page_title','| Home'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .table .thead-dark th {
    background-color: #2c3172 !important;
}
</style>
<div class="page_height pb-5">
    <div class="page-title">
        <div class="title_left">
            <h1>Students <span class="size16">List</span></h1>
			
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12 col-sm-12 ">
            <?php if(session('msg')!=""): ?>
            <div class="alert alert-<?php echo e(session('alert')); ?> alert-dismissible fade show text-center d-block" role="alert">
                <?php echo e(session('msg')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <div class="x_panel">
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box ">
                                <table id="cargo_table" class="table table-striped table-bordered" >
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>#</th>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>State</th>
                                            <th>Status</th>
                                            <!-- <th>Brocker Info</th> -->
                                            <th >Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($count++); ?></td>
                                            <td><?php echo e($row->id); ?></td>
                                            <td><?php echo e($row->studentDetail->firstname ?? ''); ?></td>
                                            <td><?php echo e($row->email); ?></td>
                                            <td><?php echo e($row->studentDetail->state->name ?? ''); ?></td>
                                            
                                            <td>
                                                <?php if($row->status =="1"): ?>
                                                <span class="badge badge-success">Active</span>
                                                <?php else: ?>
                                                <span class="badge badge-danger">In-Active</span>
                                                <?php endif; ?>
                                            </td>

                                            <td >
                                                <div class="btn-group" style="display: -webkit-box;">
                                                    <a href=<?php echo e(route('admin.students.view', ['id' => $row->id])); ?>

                                                        class="btn left_col btn-sm ml-2 pt-1 pb-1 rounded"><i class="fas fa-solid fa-eye text-white"></i></a>
                                                    
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/admin/students/list.blade.php ENDPATH**/ ?>