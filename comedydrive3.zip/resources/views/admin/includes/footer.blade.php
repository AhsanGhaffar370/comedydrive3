
    <!-- footer content -->
    <footer>
        <div class="pull-right">
        Copyright © 2018 <a href={{route('admin.dashboard')}} class="cl_bd">Comedy Drive</a>. All rights reserved. 
        </div>
        <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
    </div>
</div>

@include('admin/includes/script')