
<?php echo $__env->make('front/includes/styling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<header>
	<div class="main-header">
		<div class="container">
			<div class="menu-Bar">
				<span></span>
				<span></span>
				<span></span>
			</div>
			<div class="row align-items-center">
				<div class="col-md-3 text-center">
					<a href="./" class="logo">
					<img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
					</a>
				</div>
				<div class="col-md-9">
					<div class="menuWrap">
					<ul class="menu">
                        <li class="active"><a  href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('question')); ?>">Got Questions?</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                        <li><a href="<?php echo e(route('course')); ?>">Re-Enter Course</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student')): ?>
                            <li><a href="<?php echo e(route('get_enrolled_courses')); ?>">Resume Course</a></li>
                            <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                        <?php endif; ?>
                        (<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('student')): ?>)
                            <li><a href="<?php echo e(route('get_enrolled')); ?>">Register</a></li>
                        <?php endif; ?>
					</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header><?php /**PATH D:\comedydrive3\resources\views/front/includes/header.blade.php ENDPATH**/ ?>