

<?php $__env->startSection('page_title','| Courses'); ?>

<?php $__env->startSection('content'); ?>

<div class="mainBanner renter">
         <div class="container">
         <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6">
                   <a href="#">
                        <div class="click-btn">
                     <img src="<?php echo e(asset('assets/assets/images/book.png')); ?>" alt="">
                     <div class="click-text">
                        <h2>CLICK HERE</h2>
                        <p>If you are not currently Enrolled</p>
                     </div>
                  </div>
                  </a>
               <div class="notice-wrap">

                   <div class="notice-hd">
                  <h1>NOTICE:</h1>
                  <div class="notice-text">
                     <p>The use, publication, transmission, copying,reproduction, distribution, dissemination, sale,participation in the transfer or sale, and/or any other unauthorized use or appropriation of all or any portion or part of the training course and/or certification exam, by any means whatsoever (including but not limited to, through photographic or electronic means and/or technology) without Comedy Safe Driver's prior written authorization is prohibited and will result in appropriate legal measures being taken by Comedy Safe Driver. The modification, creation of a new work(s) from, display, or exploitation in any other way of all or any portion of Comedy Safe Driver's training and/or certification examination is also prohibited without Comedy Safe Driver's prior written authorization.</p>
                  </div>
               </div>
               </div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6">
               <div class="course-wrap">
               <div class="question-hd">
                  <h1>Re-Enter Course</h1>
                  <h4>But not while you’re driving!</h4>
               </div>
              

               <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                  <div class="field">
                      <input type="email" placeholder="Email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="email" autofocus>
                      
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="field">
                      <input type="password" placeholder="Password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                      
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                           <strong><?php echo e($message); ?></strong>
                        </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                     

                         <div class="field">
                        <button type="submit">Login</button>
                        </div>
               </form>
            </div>
            </div>
         </div>
         </div>
         
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/auth/login.blade.php ENDPATH**/ ?>