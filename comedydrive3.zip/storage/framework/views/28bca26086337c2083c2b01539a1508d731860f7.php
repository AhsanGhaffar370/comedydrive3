
    <!-- footer content -->
    <footer>
        <div class="pull-right">
        Copyright © 2018 <a href=<?php echo e(route('admin.dashboard')); ?> class="cl_bd">Comedy Drive</a>. All rights reserved. 
        </div>
        <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
    </div>
</div>

<?php echo $__env->make('admin/includes/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\comedydrive3\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>